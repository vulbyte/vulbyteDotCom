let spacer = document.createElement('div');
spacer.style.height = '0px';
let spacer_height_target = "120px";
let spacer_height_increment = 10;

async function add_to_spacer_height() {
	while (parseInt(spacer.style.height, 10) < spacer_height_target) {
		// Use a promise to delay the loop
		await new Promise(resolve => setTimeout(resolve, 100));

		// Increase the spacer height
		let currentHeight = parseInt(spacer.style.height, 10); // Convert "50px" to 50
		spacer.style.height = currentHeight + spacer_height_increment + "px";

		console.log("Adding height to spacer: ", spacer.style.height);
	}
}


window.addEventListener('load', function() {
	// TODO: FIX THIS add_to_spacer_height();
	let ROOT_DIR = localStorage.getItem("ROOT_DIR");

	console.log("ROOT_DIR = ", ROOT_DIR);

	//header Element
	let header = document.createElement('header');
	//header.textContent = "⑤header header header";
	header.style.opacity = "0.0";

	let home_anchor = document.createElement('a');
	home_anchor.href = "https://vulbyte.com/";
	home_anchor.target = "_blank";
	home_anchor.style = "background-color: var(--color_background_primary); padding: 0.2em; text-decoration: none;";
	header.appendChild(home_anchor);
	home_anchor.style.borderRight = '6px solid var(--color_secondary)';

	//let home_bg = document.createElement('span');
	//home_bg.style.zIndex = `${(home_anchor.style.zIndex) - 1}`
	//home_bg.style.width = `${(home_anchor.getBoundingClientRect().width)}px`
	//home_bg.style.backgroundColor = `var(--color_secondary)`
	//home_bg.style.width = '5em';
	//home_anchor.appendChild(home_bg);

	let home_logo = document.createElement('img');
	//the link here is relivant to the html file or the project core, NOT this file

	home_logo.src = `${ROOT_DIR}/assets/icon.svg`;
	home_logo.style = 'max-width: 4.2em; max-height: 4.2em;'
	home_anchor.appendChild(home_logo);

	// TODO:ADD LOGIC FOR HOMETEXT WITH MOBILE SCREENS
	//let home_text = document.createElement('p');
	//home_text.innerText = "VULBYTE"
	//header.appendChild(home_text);gt
	//home_anchor.appendChild(home_text);

	// TODO: add: HOME, LINKS, PROJECTS <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
	let locations = ["home", "links", "projects"];

	locations.forEach((v) => {
		let newElem = document.createElement('a');
		newElem.innerText = v;

		newElem.style.alignItems = "center";
		newElem.style.display = "flex";
		newElem.style.height = "6em";
		newElem.style.textAlign = "center";
		newElem.style.justifyContent = "center";

		header.appendChild(newElem);
	});

	//let header.appendChild4gt


	//add it all to the document
	document.body.insertBefore(header, document.body.firstChild);

	//setTimeout((() => {
	//}), 500);
	console.log("header height: ", header.getBoundingClientRect().height);
	spacer.id = "spacer_for_header";
	spacer_height_target = `${header.getBoundingClientRect().height}px`;
	document.getElementsByTagName('body')[0].insertAdjacentElement("afterbegin", spacer);

	console.log("header load done, animating in");

	header.style.transitionDuration += "2000";
	header.style.opacity = "1";

	spacer.style.height = header.getBoundingClientRect().height + "px";
});

